cd web_server
node server.js

ttab -w python audio_server/audio_server.py